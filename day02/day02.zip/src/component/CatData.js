//데이터만 넣을 부분
export default [
    {
        id:1,
        img:'https://cdn.pixabay.com/photo/2017/11/14/13/06/kitty-2948404_1280.jpg',
        title:'아기냥'
    },
    {
        id:2,
        img:'https://cdn.pixabay.com/photo/2016/07/10/21/47/cat-1508613_1280.jpg',
        title:'piggy'
    },
    {
        id:3,
        img:'https://cdn.pixabay.com/photo/2018/02/21/05/17/cat-3169476_1280.jpg',
        title:'black'
    },
    {
        id:4,
        img:'https://cdn.pixabay.com/photo/2016/01/20/13/05/cat-1151519_1280.jpg',
        title:'whitegrey'
    }
]